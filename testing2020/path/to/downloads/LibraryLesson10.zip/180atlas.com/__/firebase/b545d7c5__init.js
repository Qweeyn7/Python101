if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
	"apiKey": "AIzaSyDQcOOO9yTd-cHMxbPc5F9wnoBsTs4Q53s",
	"databaseURL": "https://atlas-digital-180.firebaseio.com",
	"storageBucket": "atlas-digital-180.appspot.com",
	"authDomain": "atlas-digital-180.firebaseapp.com",
	"messagingSenderId": "813969865530",
	"projectId": "atlas-digital-180"
});
/*!
* AerWebCopy Engine [version 6.3.0]
* Copyright Aeroson Systems & Co.
* File mirrored from https://180atlas.com/__/firebase/init.js
* At UTC time: 2020-05-15 19:53:40.177966
*/
